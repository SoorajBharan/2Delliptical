#include "elliptical.h"

int main()
{
	ELLIPTICAL::elliptical<2>	ob;
	ob.run();
	return 0;
}
